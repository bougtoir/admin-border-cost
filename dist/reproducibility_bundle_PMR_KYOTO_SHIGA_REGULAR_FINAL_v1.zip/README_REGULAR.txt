PMR REGULAR-ISSUE reproducibility bundle (v1)
=========================================
Contents identical to the audited v2 bundle: analysis code, generated metrics, results, and manuscript assets. The retargeting changed only journal-facing text (abstract, anonymization, cover letter, title page); NO analysis was rerun and no canonical result changed.

Public repo: https://github.com/bougtoir/admin-border-cost (main; synchronized, see FINAL_HANDOFF_PMR_REGULAR.txt for SHA)
Reproduction: clean clone -> fresh env -> python src/pmr/run_access_analyses.py (verified PASS_WITH_NOTE, docs/FINAL_PUBLIC_REPRODUCIBILITY_AUDIT.md + FINAL_REPRODUCIBILITY_DIFF.csv)
