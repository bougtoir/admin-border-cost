# PMR Kyoto–Shiga — New-Data Provenance (FINAL)

Date: 2026-10-06 (UTC). Consolidated provenance for all data acquired for
the PMR extension analyses. Every entry follows
`docs/PMR_KYOTO_SHIGA_NEW_DATA_PROVENANCE.md` §1.

## Acquired

| Field | Value |
|---|---|
| Dataset | National Land Numerical Information, P29 学校 (schools) |
| Source | Ministry of Land, Infrastructure, Transport and Tourism (MLIT), nlftp.mlit.go.jp/ksj |
| URL | https://nlftp.mlit.go.jp/ksj/gml/data/P29/P29-21/P29-21_GML.zip |
| Version/date | 2021 data year (Reiwa-3), released 2022-03; national file, JGD2011, 57,230 records |
| Retrieval UTC | 2026-10-06 |
| License/status | MLIT National Land Numerical Information usage terms (attribution; research use permitted) |
| SHA-256 | 1e161d40ec3319e6840628a3de524a84098c3be38157d54f82fcaa4ef0c37591 (ledgered in `data/raw/SHA256SUMS.txt`) |
| Geographic coverage | National → filtered to Kyoto (admin codes 26xxx) + Shiga (25xxx) |
| Variables used | P29_001 admin area code; P29_002 school code; P29_003 school type; P29_004 name; P29_005 address; P29_006 admin type; P29_007 open/closed flag; point coordinates |
| Transformations | Prefecture filter (25/26); per-level open subsets (P29_007==1); public subsets (P29_006!=4). Builder: `src/pmr/build_education_access_data.py`. Raw archive untouched. |
| Outputs | `data/processed/pmr_education_access/p29_schools_kyoto_shiga_all.csv` (1,877); `p29_elementary_open_kyoto_shiga.csv` (572); `p29_elementary_open_public_kyoto_shiga.csv` (571); `p29_junior_high_open_kyoto_shiga.csv` (262); `p29_junior_high_open_public_kyoto_shiga.csv` (256) |

## Not yet acquired

- Healthcare facility points (candidate: MLIT P04 medical/welfare
  facilities, Kyoto + Shiga) — needed for F1.
- Demand-side centroids: reuse of canonical 2020 census small-area
  populations (A1/A2, `docs/DATA_PROVENANCE.md`) — permitted, no new
  acquisition required.

## Rule status

No data from any unrelated project is included. If further data cannot
be obtained under these rules, the extension stops and the paper
proceeds as conceptual + electoral worked example (§3 stop rule of the
provenance protocol).
