# PMR Kyoto–Shiga Extension — New-Data Provenance Protocol

Date: 2026-10-05 (UTC). Status: **No new data acquired yet** — this file
pre-specifies provenance requirements for the extension analyses frozen
in `docs/PMR_KYOTO_SHIGA_FUNCTION_SELECTION_FREEZE.md`. It is created
now so that any acquisition inherits the rules before it happens.

## 1. Requirements for any new dataset

Every new input must be Kyoto–Shiga-specific and documented with:

- official source URL;
- dataset name and version/release;
- retrieval timestamp (UTC);
- license/terms status;
- SHA-256 checksum (added to `data/raw/SHA256SUMS.txt`);
- geographic coverage;
- variables used;
- transformations applied (in `src/`, never manual edits to raw).

Raw originals are immutable snapshots under `data/raw/`; processing writes
only to `data/interim`/`data/processed`. Re-downloads never overwrite an
existing snapshot. Processed data from any unrelated project must not be
reused.

## 2. Planned sources (candidates, to verify at acquisition)

| Function | Planned source | Host | Notes |
|---|---|---|---|
| F1 Healthcare access | National Land Numerical Information, medical/welfare facilities (P04), Kyoto (26) + Shiga (25) archives | MLIT, nlftp.mlit.go.jp/ksj | Facility points; tier by facility class |
| F2 Education access | National Land Numerical Information, educational institutions, Kyoto + Shiga | MLIT, nlftp.mlit.go.jp/ksj | Public elementary/junior-high points |
| Demand weights | 2020 census small-area population (already held: A1/A2 in `docs/DATA_PROVENANCE.md`) | MIC e-Stat | Reuse of THIS project's canonical data is permitted |
| Optional travel time | Open road-network data only if license-clean; otherwise geodesic with speed assumption | TBD at acquisition | Recorded before solving |

## 3. Stop rule

If suitable official data cannot be obtained and ledgered, the empirical
extension **stops**: the PMR paper proceeds as conceptual + electoral
worked example only. No service analysis may be fabricated or imported
from another project.
